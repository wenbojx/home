//
//  ChatViewController.m
//  Chat
//
//  Created by HuTao on 8/22/12.
//  Copyright __MyCompanyName__ 2012. All rights reserved.
//

#import "ChatViewController.h"
#import "ChatViewCell.h"


@implementation ChatViewController



@synthesize dataList;



//返回UITableView共几行
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
	return [dataList count];
}


//该方法在UITableView显示一行时自动被调用
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
	//必须和在ChatViewCell.xib中的设置一致（也可以不一致，但UITableViewCell的重用机制将无效）
	static NSString * cellIdentifier = @"CellIdentifier";
	
	//该方法第一次调用时返回nil(因为程序刚开始运行时并没有可以重用的UITableViewCell)
	ChatViewCell * cell = (ChatViewCell *)[tableView dequeueReusableCellWithIdentifier:cellIdentifier];
	if (cell == nil)
	{
		//加载ChatViewCell.xib
		NSArray * array = [[NSBundle mainBundle] loadNibNamed:@"ChatViewCell" owner:self options:nil]; 
		cell = [array objectAtIndex:0];
		//选中时呈蓝色高亮
		[cell setSelectionStyle:UITableViewCellSelectionStyleBlue];
		//[cell setSelectionStyle:UITableViewCellSelectionStyleGray]; 
	} 	
	
	NSUInteger row = [indexPath row];
	NSMutableDictionary * person = [dataList objectAtIndex:row];
	cell.labelName.text = [person objectForKey:@"name"];
	cell.labelStatus.text = [person objectForKey:@"status"];
	cell.labelRemarks.text = [person objectForKey:@"remarks"];
	[cell.imageViewHead setImage:[UIImage imageNamed:[person objectForKey:@"image"]]];
	return cell;
	
}


//UITableView行高
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
	//和ChatViewCell.xib中的设置一致，这样才会完全重合
	return 100.0;
}


//该方法在点击UITableView的某一行前自动被调用，如果返回nil，则点击后高亮选中会消失，否则会一直存在
- (NSIndexPath *)tableView:(UITableView *)tableView willSelectRowAtIndexPath:(NSIndexPath *)indexPath
{ 
	return nil;
}



-(void)addPerson:(NSString *)name status:(NSString *)status remarks:(NSString *)remarks image:(NSString *)imageName
{
	NSMutableDictionary * person = [[NSMutableDictionary alloc] init];

	[person setValue:name forKey:@"name"];
	[person setValue:status forKey:@"status"];
	[person setValue:remarks forKey:@"remarks"];
	[person setValue:imageName forKey:@"image"];

	[dataList addObject:person];
}



// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad
{
	[super viewDidLoad];
	
	dataList = [[NSMutableArray alloc] init];
	
	[self addPerson:@"张三" status:@"离线" remarks:@"今天好累啊" image:@"1.jpg"];
	[self addPerson:@"李四" status:@"在线" remarks:@"明天要交作业，不写完不睡觉！" image:@"2.jpg"];
	[self addPerson:@"王五" status:@"在线" remarks:@"打Dota！" image:@"3.jpg"];
	[self addPerson:@"我是超人" status:@"忙碌" remarks:@"好无聊，想睡觉～～" image:@"4.jpg"];
	[self addPerson:@"小红" status:@"隐身" remarks:@"地球是我们共同的家园，让我们一同保卫地球" image:@"5.jpg"];
	[self addPerson:@"芳芳" status:@"离线" remarks:@"谁和我一起去看电影啊？" image:@"6.jpg"];
	[self addPerson:@"小明" status:@"隐身" remarks:@"每天都是崭新的一天，加油" image:@"7.jpg"];
	[self addPerson:@"大宝" status:@"忙碌" remarks:@"昨天钱包丢了，悲剧！" image:@"8.jpg"];
}


- (void)viewDidUnload
{
	dataList = nil;
}


- (void)dealloc
{
	[super dealloc];
	
	[dataList release];
}

@end
