//
//  ChatViewCell.h
//  Chat
//
//  Created by HuTao on 8/22/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface ChatViewCell : UITableViewCell
{
	IBOutlet UIImageView * imageViewHead;
	IBOutlet UILabel * labelName;
	IBOutlet UILabel * labelStatus;
	IBOutlet UILabel * labelRemarks;
}



@property (retain, nonatomic) IBOutlet UIImageView * imageViewHead;
@property (retain, nonatomic) IBOutlet UILabel * labelName;
@property (retain, nonatomic) IBOutlet UILabel * labelStatus;
@property (retain, nonatomic) IBOutlet UILabel * labelRemarks;


@end
