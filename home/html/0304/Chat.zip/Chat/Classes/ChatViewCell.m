//
//  ChatViewCell.m
//  Chat
//
//  Created by HuTao on 8/22/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import "ChatViewCell.h"


@implementation ChatViewCell


@synthesize imageViewHead;
@synthesize labelName;
@synthesize labelStatus;
@synthesize labelRemarks;



- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
	if ((self = [super initWithStyle:style reuseIdentifier:reuseIdentifier])) {
		// Initialization code
	}
	return self;
}


- (void)setSelected:(BOOL)selected animated:(BOOL)animated {

	[super setSelected:selected animated:animated];

	// Configure the view for the selected state
}


- (void)dealloc
{
	[super dealloc];
	
	[imageViewHead release];
	[labelName release];
	[labelStatus release];
	[labelRemarks release];
}


@end
