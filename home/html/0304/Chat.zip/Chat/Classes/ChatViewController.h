//
//  ChatViewController.h
//  Chat
//
//  Created by HuTao on 8/22/12.
//  Copyright __MyCompanyName__ 2012. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ChatViewController : UIViewController<UITableViewDelegate, UITableViewDataSource>
{
	NSMutableArray * dataList;
}


@property (retain, nonatomic) NSMutableArray * dataList;



-(void)addPerson:(NSString *)name status:(NSString *)status remarks:(NSString *)remarks image:(NSString *)imageName;



@end

