//
//  DGAssetCacheTests.h
//  DGAssetCacheTests
//
//  Created by Damien Glancy on 06/10/2012.
//  Copyright (c) 2012 Damien Glancy. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>
#import "SenAsyncTestCase.h"

#define STANDARD_TIMEOUT_IN_SECS 10.0

@interface DGAssetCacheTests : SenAsyncTestCase

@end
