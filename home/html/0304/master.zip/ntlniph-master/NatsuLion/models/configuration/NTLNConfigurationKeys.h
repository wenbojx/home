#define NTLN_PREFERENCE_USERID					@"userId"
#define NTLN_PREFERENCE_PASSWORD				@"password"
#define NTLN_PREFERENCE_TWITTER_USERID			@"twitter_user_id"

#define NTLN_PREFERENCE_REFRESH_INTERVAL		@"refreshInterval"
#define NTLN_PREFERENCE_USE_SAFARI				@"useSafari"
#define NTLN_PREFERENCE_DARK_COLOR_THEME		@"darkColorTheme"
#define NTLN_PREFERENCE_AUTO_SCROLL				@"autoScroll"
#define NTLN_PREFERENCE_SHOW_MORE_TWEETS_MODE	@"showMoreTweetMode"
#define NTLN_PREFERENCE_FETCH_COUNT				@"fetchCount"
#define NTLN_PREFERENCE_SHAKE_TO_FULLSCREEN		@"shakeToFullscreen"

#define NTLN_PREFERENCE_FOOTER					@"footer"

#define NTLN_PREFERENCE_LEFTHAND				@"lefthand"

#define NTLN_OAUTH_PROVIDER						@"twitter.com"
#define NTLN_OAUTH_PREFIX						@"NatsuLion"

#define NTLN_OAUTH_WAIT_FOR_CALLBACK			@"oAuthWaitForCallback"
