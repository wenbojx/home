#import <UIKit/UIKit.h>

@interface NTLNWebView : UIWebView {

}

+ (NTLNWebView*)sharedInstance;


@end
