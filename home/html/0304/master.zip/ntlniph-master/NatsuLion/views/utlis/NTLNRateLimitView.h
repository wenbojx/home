#import <UIKit/UIKit.h>

@interface NTLNRateLimitView : UIView {

}

@end
