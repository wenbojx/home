#import <UIKit/UIKit.h>

@interface NTLNTweetTextView : UITextView
@end
