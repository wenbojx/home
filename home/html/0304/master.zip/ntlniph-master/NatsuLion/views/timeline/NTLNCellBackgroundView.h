#import <UIKit/UIKit.h>

@interface NTLNCellBackgroundView : UIView
+ (void)drawBackground:(CGRect)rect backgroundColor:(UIColor*)backgroundColor;

@end
