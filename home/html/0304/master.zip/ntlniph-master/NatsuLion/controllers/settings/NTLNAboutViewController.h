#import <UIKit/UIKit.h>

@interface NTLNAboutViewController : UIViewController<UIWebViewDelegate>
@end
