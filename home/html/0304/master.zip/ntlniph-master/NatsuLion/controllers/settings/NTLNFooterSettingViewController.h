#import <Foundation/Foundation.h>
#import "UICTableViewController.h"

@interface NTLNFooterSettingViewController : UICTableViewController
@end
