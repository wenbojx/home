#import <Foundation/Foundation.h>
#import "UICTableViewController.h"

@interface NTLNTwitterAccountViewController : UICTableViewController {
	NSString *usernameOriginal;
}

@end
