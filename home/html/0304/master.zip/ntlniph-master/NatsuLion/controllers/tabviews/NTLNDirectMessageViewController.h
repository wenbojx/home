#import "NTLNTimelineViewController.h"

@interface NTLNDirectMessageViewController : NTLNTimelineViewController

@end
