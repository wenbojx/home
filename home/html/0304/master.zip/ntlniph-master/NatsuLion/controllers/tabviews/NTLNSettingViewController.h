#import <UIKit/UIKit.h>
#import "UICTableViewController.h"

@interface NTLNSettingViewController : UICTableViewController
@end
