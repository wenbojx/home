#import <UIKit/UIKit.h>
#import "NTLNTimelineViewController.h"

@interface NTLNSentsViewController : NTLNTimelineViewController {

}

@end
