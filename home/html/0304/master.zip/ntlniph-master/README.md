<h1>NatsuLion for iPhone</h1>

<h2>LICENSE</h2>

New BSD License. See LICENSE file. 
Potions of this product utilize some open sourced materials, see readme.html in detail.

<h2>For Developers</h2>

<h3>OAuth API Keys</h3>

You need twitter OAuth API Keys. Obtain from the following form,

<a href="http://twitter.com/oauth_clients/new">http://twitter.com/oauth_clients/new</a>

and store the "Consumer key" and "Consumer secret" in twitter_apikeys.h.

The form must be selected or filled the following values:
<ul>
<li>Application Type: Browser</li>
<li>Callback URL: http://iphone.natsulion.org/oauth_callback</li>
<li>Default Access type: Read & Write</li>
</ul>

<h2>Github committers:</h2>
<ul>
<li><a href="http://github.com/takuma104">takuma104 (http://github.com/takuma104)</a></li>
<li><a href="http://github.com/mootoh">mootoh (http://github.com/mootoh)</a></li>
</ul>
