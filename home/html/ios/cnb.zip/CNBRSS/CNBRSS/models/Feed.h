#import <Foundation/Foundation.h>

@interface Feed : NSObject <NSURLConnectionDataDelegate>
{
    int articleID;
    int readCount;
    int commentCount;
    int rememberCount;
    NSString *title;
    NSString *subtitle1;
    NSString *subtitle2;
    NSString *imageURL;
    NSDate *datePub;
    NSString *feedContent;
    NSMutableData *responseData;
    NSMutableArray *listFeeds;
}

@property (nonatomic, assign) int articleID;
@property (nonatomic, assign) int readCount;
@property (nonatomic, assign) int commentCount;
@property (nonatomic, assign) int rememberCount;
@property (nonatomic, retain) NSString *title;
@property (nonatomic, retain) NSString *subtitle1;
@property (nonatomic, retain) NSString *subtitle2;
@property (nonatomic, retain) NSString *imageURL;
@property (nonatomic, retain) NSDate *datePub;
@property (nonatomic, retain) NSString *feedContent;
@property (nonatomic, retain) NSMutableData *responseData;
@property (nonatomic, retain) NSMutableArray *listFeeds;


- (id)initWithTitle:(NSString*)aTitle subtitle1:(NSString*)aSubtitle1 subtitle2:(NSString*)aSubtitle2 imageURL:(NSString*)anImageURL;
- (void)getHtmlFromURLWithPath:(int)page;
- (NSMutableArray *)returnArray;
- (void)getFeedContent:(int)_id delegate:(id)_aDelegate;
- (NSString *)clearHtml:(NSString *)_content;

@end
