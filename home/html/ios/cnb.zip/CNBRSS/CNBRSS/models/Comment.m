#import "Comment.h"
#import "HTMLParser.h"
#import "RegexKitLite.h"

@implementation Comment

@synthesize name;
@synthesize time;
@synthesize content;
@synthesize support;
@synthesize against;

- (id)initWithName:(NSString*)aName time:(NSDate*)aTime content:(NSString*)aContent support:(int)aSupport against:(int)anAgainst 
{
    self = [super init];
    if (self) {
        name = [aName retain];
        time = [aTime retain];
        content = [aContent retain];
        support = aSupport;
        against = anAgainst;
    }
    return self;
}

+ (NSMutableArray *)parseCommentFromData:(NSData *)data
{
    NSError *error = nil;
    NSMutableArray *list = [[NSMutableArray alloc] init];
    NSString *content = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
    // 处理标签
    NSString *content_step1 = [[content stringByReplacingOccurrencesOfString:@"&lt;" withString:@"<"] stringByReplacingOccurrencesOfString:@"&gt;" withString:@">"];
    
    HTMLParser *parser = [[HTMLParser alloc] initWithString:content_step1 error:&error];
    HTMLNode *bodyNode = [parser body];
    NSArray *commentNodes = [bodyNode findChildTags:@"dl"];
    
    for (HTMLNode *commentNode in commentNodes) {
        // 显示名称
        NSString *_name = [[commentNode findChildTag:@"strong"] contents];
        
        // 获取评论时间
        NSString *_time = [[[commentNode findChildOfClass:@"re_author"] rawContents] stringByMatching:@"\\s*(\\d{4}-\\d{2}-\\d{2}\\s\\d{2}:\\d{2}:\\d{2})\\s*" capture:1L];
        NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
        [dateFormatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
        NSDate *_datePub = [dateFormatter dateFromString:_time];
        
        // 获取评论内容
        NSString *_content = [[commentNode findChildOfClass:@"re_detail"] contents];
        _content = [_content stringByReplacingOccurrencesOfRegex:@"\\s*|\\t|\\r|\\n" withString:@""];
        
        // 获取支持数
        NSString *_support = [[commentNode rawContents] stringByMatching:@"<span\\s+id=\"support[^>]+>(\\d+)</span>" capture:1L];
        // 获取反对数
        NSString *_against = [[commentNode rawContents] stringByMatching:@"<span\\s+id=\"against[^>]+>(\\d+)</span>" capture:1L];
        Comment *comment = [[Comment alloc] initWithName:_name time:_datePub content:_content support:[_support intValue] against:[_against intValue]];
        [list addObject:comment];
    }
    
    return list;
}

@end
