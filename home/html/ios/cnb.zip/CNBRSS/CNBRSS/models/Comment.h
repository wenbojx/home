#import <Foundation/Foundation.h>

@interface Comment : NSObject
{
    NSString *name;
    NSDate *time;
    NSString *content;
    int support;
    int against;
}

@property (nonatomic, retain) NSString *name;
@property (nonatomic, retain) NSDate *time;
@property (nonatomic, retain) NSString *content;
@property (nonatomic, assign) int support;
@property (nonatomic, assign) int against;

- (id)initWithName:(NSString*)aName time:(NSDate*)aTime content:(NSString*)aContent support:(int)aSupport against:(int)anAgainst;

+ (NSMutableArray *)parseCommentFromData:(NSData *)data;

@end
