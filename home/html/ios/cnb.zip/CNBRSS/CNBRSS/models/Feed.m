#import "Feed.h"
#import "HTMLParser.h"
#import "NSDate+TimeAgo.h"
#import "RegexKitLite.h"
#import "AFXMLRequestOperation.h"
#import "NSString_stripHtml.h"

@implementation Feed

@synthesize title;
@synthesize subtitle1;
@synthesize subtitle2;
@synthesize imageURL;
@synthesize datePub;
@synthesize articleID;
@synthesize readCount;
@synthesize commentCount;
@synthesize rememberCount;
@synthesize responseData;
@synthesize listFeeds;
@synthesize feedContent;

- (id)init
{
    self = [super init];
    if (self) {
        listFeeds = [[NSMutableArray alloc] init];
    }
    
    return self;
}

- (id)initWithTitle:(NSString*)aTitle subtitle1:(NSString*)aSubtitle1 subtitle2:(NSString*)aSubtitle2 imageURL:(NSString*)anImageURL 
{
    self = [super init];
    if (self) {
        title = [aTitle retain];
        subtitle1 = [aSubtitle1 retain];
        subtitle2 = [aSubtitle2 retain];
        imageURL = [anImageURL retain];
        datePub = [[NSDate alloc] init];
        responseData = [[NSMutableData alloc] init];
        listFeeds = [[NSMutableArray alloc] init];
    }
    
    return self;
}

- (void)dealloc
{
    [feedContent release];
    [title release];
    [subtitle1 release];
    [subtitle2 release];
    [imageURL release];
    [datePub release];
    [responseData release];
    [listFeeds release];
    [super dealloc];
}

- (void)getHtmlFromURLWithPath:(int)page
{
    NSURL *url = [NSURL URLWithString:[NSString stringWithFormat:@"http://www.cnbeta.com/pagedata0.php?pageID=%d&randnum=%d", page, (1 + arc4random() % (999999-1+1))]];
    NSMutableURLRequest *theRequest = [[NSMutableURLRequest alloc] initWithURL:url cachePolicy:NSURLRequestReloadIgnoringLocalCacheData timeoutInterval:60];
    responseData = [[NSMutableData alloc] init];
    [theRequest addValue:@"gzip,deflate" forHTTPHeaderField:@"Accept-Encoding"];
    [theRequest addValue:@"*/*" forHTTPHeaderField:@"Accept"];
    [theRequest addValue:@"Mozilla/5.0 AppleWebKit/533.1 (KHTML, like Gecko)" forHTTPHeaderField:@"User-Agent"];
    [theRequest addValue:@"http://www.cnbeta.com/" forHTTPHeaderField:@"Referer"];
    [theRequest addValue:@"zh-cn" forHTTPHeaderField:@"Accept-Language"];
    
    NSURLConnection *connection = [NSURLConnection connectionWithRequest:theRequest delegate:self];
    
    if (connection == nil) {
        NSString *message = NSLocalizedString (@"Unable to initiate request.",
                                               @"NSURLConnection initialization method failed.");
        NSLog(@"error: %@", message);
    }
    [theRequest release];
}

#pragma mark - NSURLConnectionDelegate
- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
    [responseData appendData:data];
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    NSError *error = nil;
    NSStringEncoding encoding = CFStringConvertEncodingToNSStringEncoding(kCFStringEncodingGB_18030_2000);
    NSString *text = [[NSString alloc] initWithData:responseData encoding:encoding];
    
    HTMLParser *parser = [[HTMLParser alloc] initWithString:text error:&error];
    
    if (error) {
        NSLog(@"Error: %@", error);
    }
    
    if ([listFeeds count]) {
        [listFeeds removeAllObjects];
    }
    HTMLNode *bodyNode = [parser body];
    NSArray *newsNodes = [bodyNode findChildrenOfClass:@"newslist"];
    
    for (HTMLNode *newsNode in newsNodes) {
        // 获取文章ID
        NSString *_articleID_temp = [[newsNode findChildOfClass:@"topic"] rawContents];
        NSString *_articleID = [_articleID_temp stringByMatching:@"/(\\d+)\\.htm" capture:1L];

        // 获取标题
        NSString *_title = [[newsNode findChildTag:@"strong"] contents];
        // 获取图片地址
        NSString *_imageURL = [[newsNode findChildTag:@"img"] getAttributeNamed:@"src"];
        // 获取第一行原始描述
        NSString *subtitle1_origin = [[newsNode findChildOfClass:@"author"] rawContents];
        // 获取发布时间
        NSString *_datePub_str = [subtitle1_origin stringByMatching:@"\\s*(\\d{4}-\\d{2}-\\d{2}\\s\\d{2}:\\d{2}:\\d{2})\\s*" capture:1L];

        NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
        [dateFormatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
        NSDate *_datePub = [dateFormatter dateFromString:_datePub_str];
        // 获取阅读次数
        NSString *_readCount = [subtitle1_origin stringByMatching:@"\\|\\s*(\\d+)\\s*次阅读" capture:1L];
        // 获取推荐次数
        NSString *_rememberCount = [subtitle1_origin stringByMatching:@"\\|\\s*(\\d+)\\s*次推荐" capture:1L];
        // 重新格式化第一行描述
        NSString *_subtitle1 = [NSString stringWithFormat:@"发布于%@ | %@次阅读", [_datePub timeAgo], _readCount];
        
        // 获取第二行原始描述
        NSString *subtitle2_origin = [[newsNode findChildOfClass:@"detail"] rawContents];
        // 获取评论数
        NSString *_commentCount = [subtitle2_origin stringByMatching:@"已有(\\d+)\\s*个意见" capture:1L];
        
        // 重新格式化第二行描述
        NSString *_subtitle2 = [NSString stringWithFormat:@"已有%@个评论 | %@次推荐", _commentCount, _rememberCount];
        Feed *feed = [[Feed alloc] initWithTitle:_title subtitle1:_subtitle1 subtitle2:_subtitle2 imageURL:[_imageURL stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]];
        feed.articleID = [_articleID intValue];
        feed.readCount = [_readCount intValue];
        feed.rememberCount = [_rememberCount intValue];
        feed.commentCount = [_commentCount intValue];
        feed.datePub = _datePub;
        [listFeeds addObject:feed];
        [feed release];
        [dateFormatter release];
    }
    
    [[NSNotificationCenter defaultCenter] postNotificationName:@"finishLoadRSS" object:nil];
    [parser release];
    responseData = nil;

}

- (NSMutableArray *)returnArray
{
    return listFeeds;
}

- (void)getFeedContent:(int)_id delegate:(id)_aDelegate
{
    NSString *url = [NSString stringWithFormat:@"http://m.cnbeta.com/marticle.php?sid=%d", self.articleID];
    NSURLRequest *request = [NSURLRequest requestWithURL:[NSURL URLWithString:url]];
    AFHTTPRequestOperation *operation = [AFHTTPRequestOperation HTTPRequestOperationWithRequest:request success:^(id object) {
        NSData *data = (NSData *)object;
        NSString *content = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
        NSString *content_result = [self clearHtml:content];
    } failure:^(NSHTTPURLResponse *response, NSError *error) {
        NSLog(@"error");
    }];


    NSOperationQueue *queue = [[[NSOperationQueue alloc] init] autorelease];
    [queue addOperation:operation];
}

- (NSString *)clearHtml:(NSString *)_content
{
    NSError *error = nil;
    HTMLParser *parser = [[HTMLParser alloc] initWithString:_content error:&error];
    HTMLNode *bodyNode = [parser body];
    NSString *_feedContent = [[bodyNode findChildTag:@"card"] rawContents];
    self.feedContent = _feedContent;
    
    // 处理标签
    NSString *content_step1 = [[_feedContent stringByReplacingOccurrencesOfString:@"&lt;" withString:@"<"] stringByReplacingOccurrencesOfString:@"&gt;" withString:@">"];
    
    // 去掉结尾字符
    NSString *content_step2 = [content_step1 stringByReplacingOccurrencesOfRegex:@"<(a)[^>]+>查看评论</a>" withString:@""];
    NSString *content_step2_1 = [content_step2 stringByReplacingOccurrencesOfRegex:@"<(a)[^>]+>返回cnBeta.com手机版首页</a>" withString:@""];
    
    // 去掉cards标签
    NSString *content_step3 = [content_step2_1 stringByReplacingOccurrencesOfRegex:@"<card[^>]+>|</card>" withString:@""];
    
    // 获取正文内容开始处
    NSMutableString *content_step4 = [NSMutableString stringWithFormat:@"<style>*{margin:0;padding:0; font-size:14px;-webkit-touch-callout:none;-webkit-user-select:none; } img{max-width: 310px; width: auto; height: auto;} h1{display:block;background:#ccc;padding:10px 0 10px 10px;} #mm_content{padding:5px;}</style><h1>%@</h1><div id=\"mm_content\"><p style=\"text-indent:2em;\">", self.title];
    
    NSArray *array = [content_step3 componentsSeparatedByString:@"<br>"];
    for (int i = 0; i < [array count]; i++) {
        if (i > 5) {
            [content_step4 appendFormat:@"%@<br>", [array objectAtIndex:i]];
        }
    }
    // 添加结尾div标签
    [content_step4 appendString:@"</div>"];
    
    // 去掉一些html标签
    NSString *content_output = [content_step4 stringByReplacingOccurrencesOfRegex:@"<(span|b[^r]+|a)[^>]+>|</(span|b[^r]|a|card)>" withString:@""];

    return content_output;
}

@end
