#import "CommentCell.h"

#define FONT_SIZE 14.0f
#define CELL_CONTENT_WIDTH 320.0f
#define CELL_CONTENT_MARGIN 5.0f
#define PICWIDTH 16.0F
#define PICHEIGHT 16.0F

@implementation CommentCell

@synthesize lblName;
@synthesize lblTime;
@synthesize lblComment;
@synthesize lblSupport;
@synthesize lblSupportVote;
@synthesize lblAgainst;
@synthesize lblAgainstVote;



- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
}

- (void)layoutSubviews
{
    [super layoutSubviews];
    CGFloat left = CELL_CONTENT_MARGIN * 2 + PICWIDTH;
    // 定位lblName
    CGSize textNameSize = [lblName.text sizeWithFont:[UIFont systemFontOfSize:FONT_SIZE]];
    lblName.frame = CGRectMake(left, CELL_CONTENT_MARGIN, textNameSize.width, textNameSize.height);
    
    // 定位lblTime
    CGSize textTimeSize = [lblTime.text sizeWithFont:[UIFont systemFontOfSize:FONT_SIZE]];
    lblTime.frame = CGRectMake(left + CELL_CONTENT_MARGIN + textNameSize.width, CELL_CONTENT_MARGIN, textTimeSize.width, textTimeSize.height);
    
    // 定位lblComment
    CGSize textCommentSize = [lblComment.text sizeWithFont:[UIFont systemFontOfSize:FONT_SIZE] constrainedToSize:CGSizeMake(CELL_CONTENT_WIDTH - CELL_CONTENT_MARGIN * 2, MAXFLOAT) lineBreakMode:UILineBreakModeWordWrap];
    lblComment.frame = CGRectMake(CELL_CONTENT_MARGIN, CELL_CONTENT_MARGIN * 2 + PICHEIGHT, CELL_CONTENT_WIDTH - CELL_CONTENT_MARGIN * 2, textCommentSize.height);
    
    // 定位support和against
    CGFloat currentHeight = CELL_CONTENT_MARGIN * 3 + PICHEIGHT + textCommentSize.height;
    lblSupport.frame = CGRectMake(CELL_CONTENT_MARGIN * 2, currentHeight, 28, 18);
//    CGSize textSupportVoteSize = [lblSupportVote.text sizeWithFont:[UIFont systemFontOfSize:FONT_SIZE]];
    lblSupportVote.frame = CGRectMake(CELL_CONTENT_MARGIN * 2 + 28, currentHeight, 50, 18);
    
    lblAgainst.frame = CGRectMake(CELL_CONTENT_MARGIN * 3 + 28 + 50, currentHeight, 28, 18);
//    CGSize textAgainstVoteSize = [lblAgainstVote.text sizeWithFont:[UIFont systemFontOfSize:FONT_SIZE]];
    lblAgainstVote.frame = CGRectMake(CELL_CONTENT_MARGIN * 3 + 28 + 50 + 28, currentHeight, 28, 18);
}

- (CGFloat)getHeightOfRow
{
    CGFloat height = CELL_CONTENT_MARGIN * 4 + PICHEIGHT;
    CGSize textCommentSize = [lblComment.text sizeWithFont:[UIFont systemFontOfSize:FONT_SIZE] constrainedToSize:CGSizeMake(CELL_CONTENT_WIDTH - CELL_CONTENT_MARGIN * 2, MAXFLOAT) lineBreakMode:UILineBreakModeWordWrap];
    
    return height + textCommentSize.height + 18;
}

@end
