#import <UIKit/UIKit.h>

@interface UINavigationController (MTCustomNavigationBar)

- (id)initWithCustomNavigationBar:(UINavigationBar *)navigationBar;

@end