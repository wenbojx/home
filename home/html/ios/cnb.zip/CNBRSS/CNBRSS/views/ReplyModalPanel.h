#import "UATitledModalPanel.h"

@interface ReplyModalPanel : UATitledModalPanel
{
	UIView			*v;
	IBOutlet UIView	*viewLoadedFromXib;
}

@property (nonatomic, retain) IBOutlet UIView *viewLoadedFromXib;

- (id)initWithFrame:(CGRect)frame title:(NSString *)title;

@end
