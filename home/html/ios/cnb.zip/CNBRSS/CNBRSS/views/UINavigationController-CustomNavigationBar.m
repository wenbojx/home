#import "UINavigationController-CustomNavigationBar.h"
#import <objc/runtime.h>

@implementation UINavigationController (MTCustomNavigationBar)

- (id)initWithCustomNavigationBar:(UINavigationBar *)navigationBar
{
    self = [self initWithNibName:nil bundle:nil];
    
    if (self)
    {
        // Init
        
        // Verify subclasses parent class is UINavigationBar
        if (navigationBar != nil && [navigationBar isKindOfClass:[UINavigationBar class]])
        {
            UINavigationBar *navigationBar__ = nil;
            
            // Get the unexposed ivar for navigation bar replacement
            Ivar ivar_navigationBar__ = object_getInstanceVariable(self, "_navigationBar", (void **)&navigationBar__);
            
            // Clean up memory if a navigation bar has already been assigned
            if (navigationBar__ != nil)
                [navigationBar__ release];
            
            // Assign the custom navigation bar to the retrieved ivar
            navigationBar__ = [navigationBar retain];
            object_setIvar(self, ivar_navigationBar__, navigationBar__);
        }
    }
    
    return self;
}

@end