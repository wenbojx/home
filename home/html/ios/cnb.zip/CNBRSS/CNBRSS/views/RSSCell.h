#import <UIKit/UIKit.h>
#import "HJManagedImageV.h"
#import "Feed.h"

@interface RSSCell : UITableViewCell
{
    HJManagedImageV *image;
    UILabel *lblTitle;
    UILabel *lblSubtitle1;
    UILabel *lblSubtitle2;
}

@property (nonatomic, retain) HJManagedImageV *image;
@property (nonatomic, retain) IBOutlet UILabel *lblTitle;
@property (nonatomic, retain) IBOutlet UILabel *lblSubtitle1;
@property (nonatomic, retain) IBOutlet UILabel *lblSubtitle2;

- (CGFloat)getHeight;
- (void) updateCellRss:(Feed *)feed;

@end
