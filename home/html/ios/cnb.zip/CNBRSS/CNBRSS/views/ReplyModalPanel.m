#import "ReplyModalPanel.h"

#define BLACK_BAR_COMPONENTS				{ 0.22, 0.22, 0.22, 1.0, 0.07, 0.07, 0.07, 1.0 }

@implementation ReplyModalPanel

@synthesize viewLoadedFromXib;

- (id)initWithFrame:(CGRect)frame title:(NSString *)title {
	if ((self = [super initWithFrame:frame])) {
		
		CGFloat colors[8] = BLACK_BAR_COMPONENTS;
		[self.titleBar setColorComponents:colors];
		self.headerLabel.text = title;
        [[NSBundle mainBundle] loadNibNamed:@"ReplyModalPanel" owner:self options:nil];
        [self.contentView addSubview:viewLoadedFromXib];
		
	}	
	return self;
}

- (void)dealloc {
    [v release];
	[viewLoadedFromXib release];
    [super dealloc];
}

- (void)layoutSubviews {
	[super layoutSubviews];
	[viewLoadedFromXib setFrame:self.contentView.bounds];
}

@end
