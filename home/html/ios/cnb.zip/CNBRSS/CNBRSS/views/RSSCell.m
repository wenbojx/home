#import "RSSCell.h"
#import "AppDelegate.h"
#import <QuartzCore/QuartzCore.h>

#define FONT_SIZE 14.0f
#define FONT_SIZE_DETAIL 12.0f
#define CELL_CONTENT_WIDTH 320.0f
#define CELL_CONTENT_MARGIN 5.0f
#define PICWIDTH 48.0F
#define PICHEIGHT 48.0F
#define UIColorFromRGB(rgbValue) [UIColor colorWithRed:((float)((rgbValue & 0xFF0000) >> 16))/255.0 green:((float)((rgbValue & 0xFF00) >> 8))/255.0 blue:((float)(rgbValue & 0xFF))/255.0 alpha:1.0]


@implementation RSSCell

@synthesize image;
@synthesize lblTitle;
@synthesize lblSubtitle1;
@synthesize lblSubtitle2;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        self.opaque = YES;
        self.contentView.backgroundColor = [UIColor whiteColor];
        self.layer.cornerRadius = 5;
        
        image = [[HJManagedImageV alloc] initWithFrame:CGRectMake(0, 0, PICWIDTH, PICHEIGHT)];
        [self.contentView addSubview:image];
        
        lblTitle = [[UILabel alloc] init];
        lblTitle.font = [UIFont systemFontOfSize:FONT_SIZE];
        //lblTitle.textColor = UIColorFromRGB(0x3B5998);
        [self.contentView addSubview:lblTitle];
        
        lblSubtitle1 = [[UILabel alloc] init];
        lblSubtitle1.font = [UIFont systemFontOfSize:FONT_SIZE_DETAIL];
        lblSubtitle1.textColor = [UIColor grayColor];
        [self.contentView addSubview:lblSubtitle1];
        
        lblSubtitle2 = [[UILabel alloc] init];
        lblSubtitle2.font = [UIFont systemFontOfSize:FONT_SIZE_DETAIL];
        lblSubtitle2.textColor = [UIColor grayColor];
        [self.contentView addSubview:lblSubtitle2];
        
        [image showLoadingWheel];
    }
    
    return self;
}

- (void)dealloc
{
    
    [image release];
    [lblTitle release];
    [lblSubtitle1 release];
    [lblSubtitle2 release];
    [super dealloc];
}

- (void)layoutSubviews
{
    [super layoutSubviews];
    CGFloat left = CELL_CONTENT_MARGIN * 2 + PICWIDTH;
    CGFloat textWidth = CELL_CONTENT_WIDTH - CELL_CONTENT_MARGIN * 2 - PICWIDTH;
    
    image.frame = CGRectMake(CELL_CONTENT_MARGIN, CELL_CONTENT_MARGIN, PICWIDTH, PICHEIGHT);
    CGSize txtTitleSize = [lblTitle.text sizeWithFont:[UIFont systemFontOfSize:FONT_SIZE] forWidth:textWidth lineBreakMode:UILineBreakModeTailTruncation];
    CGSize txtSubtitleSize = [lblSubtitle1.text sizeWithFont:[UIFont systemFontOfSize:FONT_SIZE_DETAIL] forWidth:textWidth lineBreakMode:UILineBreakModeTailTruncation];
    
    lblTitle.frame = CGRectMake(left, CELL_CONTENT_MARGIN, textWidth, txtTitleSize.height);
    
    lblSubtitle1.frame = CGRectMake(left, CELL_CONTENT_MARGIN + txtTitleSize.height, textWidth, txtSubtitleSize.height);
    
    lblSubtitle2.frame = CGRectMake(left, CELL_CONTENT_MARGIN + txtTitleSize.height + txtSubtitleSize.height, textWidth, txtSubtitleSize.height);
}

- (void) updateCellRss:(Feed *)feed
{
    self.image.url = [NSURL URLWithString:feed.imageURL];
    AppDelegate *delegate = [[UIApplication sharedApplication] delegate];
    [delegate.imgMan manage:self.image];
    self.lblTitle.text = feed.title;
    self.lblSubtitle1.text = feed.subtitle1;
    self.lblSubtitle2.text = feed.subtitle2;
}

- (CGFloat)getHeight
{
    CGFloat height = 0;
    CGFloat defaultHeight = CELL_CONTENT_MARGIN * 2 + PICHEIGHT;
    CGFloat textWidth = CELL_CONTENT_WIDTH - CELL_CONTENT_MARGIN * 3 - PICWIDTH;
    
    CGSize txtTitleSize = [lblTitle.text sizeWithFont:[UIFont systemFontOfSize:FONT_SIZE] forWidth:textWidth lineBreakMode:UILineBreakModeTailTruncation];
    
    CGSize txtSubitleSize = [lblSubtitle1.text sizeWithFont:[UIFont systemFontOfSize:FONT_SIZE_DETAIL] forWidth:textWidth lineBreakMode:UILineBreakModeTailTruncation];
    height = CELL_CONTENT_MARGIN * 2 + txtTitleSize.height;
    height += txtSubitleSize.height * 2;
    
    if (height < defaultHeight) {
        return defaultHeight;
    }    
    
    return height;
}
@end
