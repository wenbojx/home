#import <UIKit/UIKit.h>

@interface CommentCell : UITableViewCell
{
    IBOutlet UILabel *lblName;
    IBOutlet UILabel *lblTime;
    IBOutlet UILabel *lblComment;
    IBOutlet UILabel *lblSupport;
    IBOutlet UILabel *lblSupportVote;
    IBOutlet UILabel *lblAgainst;
    IBOutlet UILabel *lblAgainstVote;
}

@property (nonatomic, retain) IBOutlet UILabel *lblName;
@property (nonatomic, retain) IBOutlet UILabel *lblTime;
@property (nonatomic, retain) IBOutlet UILabel *lblComment;
@property (nonatomic, retain) IBOutlet UILabel *lblSupport;
@property (nonatomic, retain) IBOutlet UILabel *lblSupportVote;
@property (nonatomic, retain) IBOutlet UILabel *lblAgainst;
@property (nonatomic, retain) IBOutlet UILabel *lblAgainstVote;

- (CGFloat)getHeightOfRow;

@end
