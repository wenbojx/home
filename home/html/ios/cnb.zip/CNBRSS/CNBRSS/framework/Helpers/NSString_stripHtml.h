// NSString_stripHtml.h
// Copyright 2011 Leigh McCulloch. Released under the MIT license.

#import <Foundation/Foundation.h>

@interface NSString (stripHtml)
- (NSString*)stripHtml;
@end