@interface NSDate (TimeAgo)
-(NSString *)timeAgo;    
@end

