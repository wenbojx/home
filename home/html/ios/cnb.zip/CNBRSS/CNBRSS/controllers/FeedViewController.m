#import "FeedViewController.h"
#import "AFHTTPRequestOperation.h"
#import "SVProgressHUD.h"
#import "CommentViewController.h"
#import "ReplyModalPanel.h"

@interface FeedViewController()
- (void)back;
- (void)setupPrototypes;
//- (void)saveButtonPushed;
- (void)commentButtonPushed;
- (void)replyButtonPushed:(id)sender;
@end

@implementation FeedViewController

@synthesize webView;
@synthesize feed;
@synthesize rightButton;
@synthesize toolbar;

#pragma mark - Private method

- (void)loadFeedContent
{
    NSString *url = [NSString stringWithFormat:@"http://m.cnbeta.com/marticle.php?sid=%d", feed.articleID];
    NSURLRequest *request = [NSURLRequest requestWithURL:[NSURL URLWithString:url]];
    AFHTTPRequestOperation *operation = [AFHTTPRequestOperation HTTPRequestOperationWithRequest:request success:^(id object) {
        NSData *data = (NSData *)object;
        NSString *content = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
        // 获取到内容
        NSString *content_html = [feed clearHtml:content];
        [self.webView loadHTMLString:content_html baseURL:nil];
    } failure:^(NSHTTPURLResponse *response, NSError *error) {
        NSLog(@"error");
    }];
    [operation start];
}

- (UIButton *)createCustomButton:(UIImage *)backImage 
                       highlight:(UIImage *)backHighlightImage 
                      frontImage:(UIImage *)image
                    leftCapWidth:(CGFloat)capWidth
                           title:(NSString *)_aTitle
{
    // 创建按钮
    UIButton* button = [UIButton buttonWithType:UIButtonTypeCustom];
    // 设置按钮背景图片
    UIImage* buttonImage = [backImage stretchableImageWithLeftCapWidth:capWidth topCapHeight:0.0];
    UIImage* buttonHighlightImage = [backHighlightImage stretchableImageWithLeftCapWidth:capWidth topCapHeight:0.0];
    
    
    [button setBackgroundImage:buttonImage forState:UIControlStateNormal];
    [button setBackgroundImage:buttonHighlightImage forState:UIControlStateHighlighted];
    [button setBackgroundImage:buttonHighlightImage forState:UIControlStateSelected];
    if (image) {
        button.frame = CGRectMake(0, 0, image.size.width + 10, buttonImage.size.height);
        [button setImage:image forState:UIControlStateNormal];
        [button setImage:image forState:UIControlStateHighlighted];
        [button setImage:image forState:UIControlStateSelected];
    } else {
        CGSize textSize = [_aTitle sizeWithFont:[UIFont boldSystemFontOfSize:12.0f]];
        button.frame = CGRectMake(0, 0, textSize.width + 10, buttonImage.size.height);
        button.titleLabel.font = [UIFont boldSystemFontOfSize:12.0f];
        [button setTitle:_aTitle forState:UIControlStateNormal];
    }

    
    return button;
}

- (void)setupPrototypes
{
    [self.webView setBackgroundColor:[UIColor whiteColor]];
    for (UIView* subView in [webView subviews])
    {
        if ([subView isKindOfClass:[UIScrollView class]]) {
            for (UIView* shadowView in [subView subviews])
            {
                if ([shadowView isKindOfClass:[UIImageView class]]) {
                    [shadowView setHidden:YES];
                }
            }
        }
    }
}

- (void)setupNavButtons
{
    UIButton *backButton = [self createCustomButton:[UIImage imageNamed:@"NavBarButtonPortrait"]
                                             highlight:[UIImage imageNamed:@"NavBarButtonPortraitPressed"]
                                            frontImage:[UIImage imageNamed:@"NavBarIconBack"]
                                          leftCapWidth:5.0f
                                              title:nil];
    [backButton addTarget:self action:@selector(back) forControlEvents:UIControlEventTouchUpInside];
    
    self.navigationItem.leftBarButtonItem = [[[UIBarButtonItem alloc] initWithCustomView:backButton] autorelease];

    NSString *strComment = [NSString stringWithFormat:@"%d跟帖", feed.commentCount];
    rightButton = [self createCustomButton:[UIImage imageNamed:@"NavBarButtonPortrait"]
                                           highlight:[UIImage imageNamed:@"NavBarButtonPortraitPressed"]
                                          frontImage:nil
                                        leftCapWidth:5.0f 
                                               title:strComment];
    [rightButton addTarget:self action:@selector(commentButtonPushed) forControlEvents:UIControlEventTouchUpInside];
    self.navigationItem.rightBarButtonItem = [[[UIBarButtonItem alloc] initWithCustomView:rightButton] autorelease];
}

- (void)setupToolBar
{
    if ([toolbar respondsToSelector:@selector(setBackgroundImage:forToolbarPosition:barMetrics:)]) {
        [toolbar setBackgroundImage:[UIImage imageNamed:@"toolbarBackground"] forToolbarPosition:UIToolbarPositionAny barMetrics:UIBarMetricsDefault];
    } else {
        [toolbar insertSubview:[[[UIImageView alloc] initWithImage:[UIImage imageNamed:@"toolbarBackground"]] autorelease] atIndex:0];
    }
    
//    // 保存按钮
//    UIButton *saveButton = [self createCustomButton:[UIImage imageNamed:@"toolbarButton"]
//                                          highlight:[UIImage imageNamed:@"toolbarButtonActive"]
//                                         frontImage:nil
//                                       leftCapWidth:5.0f title:@"保存"];
//    [saveButton addTarget:self action:@selector(saveButtonPushed) forControlEvents:UIControlEventTouchUpInside];
//    UIBarButtonItem  *saveItem = [[UIBarButtonItem alloc] initWithCustomView:saveButton];
    
    // 分隔
    UIBarButtonItem *flexibleSpace = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil];
    
    // 发表评论按钮
    UIButton *replyButton = [self createCustomButton:[UIImage imageNamed:@"toolbarButton"]
                                          highlight:[UIImage imageNamed:@"toolbarButtonActive"]
                                         frontImage:nil
                                       leftCapWidth:5.0f title:@"发表评论"];
    [replyButton addTarget:self action:@selector(replyButtonPushed:) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem  *replyItem = [[UIBarButtonItem alloc] initWithCustomView:replyButton];
    
    
    
    [toolbar setItems:[NSArray arrayWithObjects:flexibleSpace, replyItem, nil]];

}

#pragma mark - Event

- (void)back
{
	[self.navigationController popViewControllerAnimated:YES];
}
//
//- (void)saveButtonPushed
//{
//    NSLog(@"save...");
//}


- (void)commentButtonPushed
{
    CommentViewController *cvc = [[CommentViewController alloc] initWithStyle:UITableViewStylePlain];
    cvc.feed = self.feed;
    [self.navigationController pushViewController:cvc animated:YES];
    [cvc release];
}

- (void)replyButtonPushed:(id)sender
{
    UAModalPanel *modalPanel = [[ReplyModalPanel alloc] initWithFrame:self.view.bounds title:@"回复"];
    [self.view addSubview:modalPanel];
    [modalPanel showFromPoint:[sender center]];
}

#pragma mark - Init and dealloc

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
    }
    
    return self;
}

- (void)dealloc
{
    [feed release];
    [webView release];
    [toolbar release];
    [super dealloc];
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self setupPrototypes];
    [self setupNavButtons];
    [self setupToolBar];
    [self loadFeedContent];
    self.webView.delegate = self;

}

- (void)viewDidUnload
{
    self.webView = nil;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

#pragma mark - WebView delegate

- (void)webViewDidStartLoad:(UIWebView *)webView
{
    [UIApplication sharedApplication].networkActivityIndicatorVisible = YES;
}

- (void)webViewDidFinishLoad:(UIWebView *)webView
{
    [UIApplication sharedApplication].networkActivityIndicatorVisible = NO;    
}

@end
