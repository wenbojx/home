#import "CommentViewController.h"
#import "CommentCell.h"
#import "NSDate+TimeAgo.h"
#import "AFHTTPRequestOperation.h"
#import "HTMLParser.h"
#import "RegexKitLite.h"
#import "Comment.h"
#import "ReplyModalPanel.h"

@interface CommentViewController()
- (void)back;
- (void)setupNavButtons;
- (void)loadComment;
- (void)replyButtonPushed:(id)sender;
@end

@implementation CommentViewController

@synthesize feed;
@synthesize arrayComment;

#pragma mark - private method
- (UIButton *)createCustomButton:(UIImage *)backImage 
                       highlight:(UIImage *)backHighlightImage 
                      frontImage:(UIImage *)image
                    leftCapWidth:(CGFloat)capWidth
                           title:(NSString *)_aTitle
{
    // 创建按钮
    UIButton* button = [UIButton buttonWithType:UIButtonTypeCustom];
    // 设置按钮背景图片
    UIImage* buttonImage = [backImage stretchableImageWithLeftCapWidth:capWidth topCapHeight:0.0];
    UIImage* buttonHighlightImage = [backHighlightImage stretchableImageWithLeftCapWidth:capWidth topCapHeight:0.0];
    
    
    [button setBackgroundImage:buttonImage forState:UIControlStateNormal];
    [button setBackgroundImage:buttonHighlightImage forState:UIControlStateHighlighted];
    [button setBackgroundImage:buttonHighlightImage forState:UIControlStateSelected];
    if (image) {
        button.frame = CGRectMake(0, 0, image.size.width + 10, buttonImage.size.height);
        [button setImage:image forState:UIControlStateNormal];
        [button setImage:image forState:UIControlStateHighlighted];
        [button setImage:image forState:UIControlStateSelected];
    } else {
        CGSize textSize = [_aTitle sizeWithFont:[UIFont boldSystemFontOfSize:12.0f]];
        button.frame = CGRectMake(0, 0, textSize.width + 10, buttonImage.size.height);
        button.titleLabel.font = [UIFont boldSystemFontOfSize:12.0f];
        [button setTitle:_aTitle forState:UIControlStateNormal];
    }
    
    
    return button;
}

- (void)back
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)setupNavButtons
{
    UIButton *backButton = [self createCustomButton:[UIImage imageNamed:@"NavBarButtonPortrait"]
                                          highlight:[UIImage imageNamed:@"NavBarButtonPortraitPressed"]
                                         frontImage:[UIImage imageNamed:@"NavBarIconBack"]
                                       leftCapWidth:5.0f
                                              title:nil];
    [backButton addTarget:self action:@selector(back) forControlEvents:UIControlEventTouchUpInside];
    self.navigationItem.leftBarButtonItem = [[[UIBarButtonItem alloc] initWithCustomView:backButton] autorelease];
    

//    UIButton *rightButton = [self createCustomButton:[UIImage imageNamed:@"NavBarButtonPortrait"]
//                                 highlight:[UIImage imageNamed:@"NavBarButtonPortraitPressed"]
//                                frontImage:nil
//                              leftCapWidth:5.0f 
//                                     title:@"发表评论"];
//    [rightButton addTarget:self action:@selector(replyButtonPushed:) forControlEvents:UIControlEventTouchUpInside];
//    self.navigationItem.rightBarButtonItem = [[[UIBarButtonItem alloc] initWithCustomView:rightButton] autorelease];
}

-(void)setupToolBar
{
    
}

- (void)loadComment
{
    NSString *url = [NSString stringWithFormat:@"http://www.cnbeta.com/comment/normal/%d.html", feed.articleID];
    NSMutableURLRequest *theRequest = [[NSMutableURLRequest alloc] initWithURL:[NSURL URLWithString:url] cachePolicy:NSURLRequestReloadIgnoringLocalCacheData timeoutInterval:60];
    NSString *articleurl = [NSString stringWithFormat:@"	http://www.cnbeta.com/articles/%d.htm", feed.articleID];
    [theRequest addValue:articleurl forHTTPHeaderField:@"Referer"];
    AFHTTPRequestOperation *operation = [AFHTTPRequestOperation HTTPRequestOperationWithRequest:theRequest success:^(id object) {
        NSData *data = (NSData *)object;
        self.arrayComment = [Comment parseCommentFromData:data];
        [self.tableView reloadData];
    } failure:^(NSHTTPURLResponse *response, NSError *error) {
        NSLog(@"error");
    }];
    
    [operation start];
}

#pragma mark - Event
- (void)replyButtonPushed:(id)sender
{
    UAModalPanel *modalPanel = [[ReplyModalPanel alloc] initWithFrame:self.view.bounds title:@"回复"];
    [self.view addSubview:modalPanel];
    [modalPanel showFromPoint:[sender center]];   
}

#pragma mark - Init and dealloc

- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
        arrayComment = [[NSMutableArray alloc] init];
    }
    return self;
}

- (void)dealloc
{
    [feed release];
    [arrayComment release];
    [super dealloc];
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self setupNavButtons];
    [self loadComment];
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [arrayComment count];
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    CommentCell *cell = (CommentCell *)[self tableView:tableView cellForRowAtIndexPath:indexPath];
    
    return [cell getHeightOfRow];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"CommentCell";
    CommentCell *cell = (CommentCell *)[self.tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        NSArray * nib = [[NSBundle mainBundle] loadNibNamed:@"CommentCell" owner:self options:nil];
        cell = [nib objectAtIndex:0];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    
    if ([arrayComment count] > 0) {
        Comment *comment = (Comment *)[arrayComment objectAtIndex:indexPath.row];
        cell.lblName.text = comment.name;
        cell.lblTime.text = [comment.time timeAgo];
        cell.lblComment.text = comment.content;
        cell.lblSupportVote.text = [NSString stringWithFormat:@"(%d)", comment.support];
        cell.lblAgainstVote.text = [NSString stringWithFormat:@"(%d)", comment.against];
    }
    
    return cell;
}

@end
