#import <UIKit/UIKit.h>
#import "Feed.h"
#import "UAModalPanel.h"

@interface FeedViewController : UIViewController <UIWebViewDelegate>
{
    Feed *feed;
    UIButton *rightButton;
    IBOutlet UIWebView *webView;
    IBOutlet UIToolbar *toolbar;
}

@property (nonatomic, retain) IBOutlet UIWebView *webView;
@property (nonatomic, retain) Feed *feed;
@property (nonatomic, retain) UIButton *rightButton;
@property (nonatomic, retain) IBOutlet UIToolbar *toolbar;

@end
