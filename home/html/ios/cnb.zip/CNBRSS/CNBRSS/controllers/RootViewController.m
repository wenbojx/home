#import "RootViewController.h"
#import "Feed.h"
#import "RSSCell.h"
#import "SVProgressHUD.h"
#import "NSDate+TimeAgo.h"
#import "FeedViewController.h"

#define FONT_SIZE 14.0f
#define FONT_SIZE_DETAIL 12.0f
#define CELL_CONTENT_WIDTH 320.0f
#define CELL_CONTENT_MARGIN 5.0f
#define PICWIDTH 48.0F
#define PICHEIGHT 48.0F

@interface RootViewController()
- (void)setupPrototypes;
- (void)setupNavButtons;
- (UIButton *)createCustomButton:(UIImage *)backImage 
                       highlight:(UIImage *)backHighlightImage 
                      frontImage:(UIImage *)image
                    leftCapWidth:(CGFloat)capWidth;
- (void)loadButtonPushed;
@end

@implementation RootViewController

@synthesize feeds;
@synthesize arrayFeeds;
@synthesize currentPage;
@synthesize _refreshHeaderView;

#pragma mark - Private methods

- (void)setupPrototypes
{
    
}

- (void)setupNavButtons
{
    self.title = @"新闻列表";
    UIButton *refreshButton = [self createCustomButton:[UIImage imageNamed:@"NavBarButtonPortrait"]
                                             highlight:[UIImage imageNamed:@"NavBarButtonPortraitPressed"]
                                            frontImage:[UIImage imageNamed:@"retry-icon"]
                                          leftCapWidth:5.0f];
    [refreshButton addTarget:self action:@selector(loadButtonPushed) forControlEvents:UIControlEventTouchUpInside];
    
    self.navigationItem.rightBarButtonItem = [[[UIBarButtonItem alloc] initWithCustomView:refreshButton] autorelease];
}

- (UIButton *)createCustomButton:(UIImage *)backImage 
                       highlight:(UIImage *)backHighlightImage 
                      frontImage:(UIImage *)image
                    leftCapWidth:(CGFloat)capWidth
{
    // 创建按钮
    UIButton* button = [UIButton buttonWithType:UIButtonTypeCustom];
    // 设置按钮背景图片
    UIImage* buttonImage = [backImage stretchableImageWithLeftCapWidth:capWidth topCapHeight:0.0];
    UIImage* buttonHighlightImage = [backHighlightImage stretchableImageWithLeftCapWidth:capWidth topCapHeight:0.0];
    
    button.frame = CGRectMake(0, 0, image.size.width + 20, buttonImage.size.height);
    [button setBackgroundImage:buttonImage forState:UIControlStateNormal];
    [button setBackgroundImage:buttonHighlightImage forState:UIControlStateHighlighted];
    [button setBackgroundImage:buttonHighlightImage forState:UIControlStateSelected];
    [button setImage:image forState:UIControlStateNormal];
    [button setImage:image forState:UIControlStateHighlighted];
    [button setImage:image forState:UIControlStateSelected];
    
    return button;
}

NSInteger sortFeedByDate(id obj1, id obj2, void *context)
{
    Feed *feed1 = (Feed *)obj1;
    Feed *feed2 = (Feed *)obj2;
    
    return [feed2.datePub compare:feed1.datePub];
}

- (void)finishLoadRSS
{
    [arrayFeeds addObjectsFromArray:[self.feeds returnArray]];
    // 排序
    [arrayFeeds sortUsingFunction:sortFeedByDate context:nil];
    currentPage++;
    [SVProgressHUD dismiss];
    [self.tableView reloadData];
}

- (void)loadMoreFeed
{
    [feeds getHtmlFromURLWithPath:self.currentPage];
}

- (void)setupEGORefresh
{
    if (_refreshHeaderView == nil) {
        EGORefreshTableHeaderView *view1 = [[EGORefreshTableHeaderView alloc] initWithFrame:CGRectMake(0.0f, 0.0f - self.tableView.bounds.size.height, self.tableView.frame.size.width, self.view.bounds.size.height)];
        view1.delegate = self;
        [self.tableView addSubview:view1];
        _refreshHeaderView = view1;
        [view1 release];
    }
    [_refreshHeaderView refreshLastUpdatedDate];
}

#pragma mark - Events

- (void)loadButtonPushed
{
    currentPage = 1;
    [arrayFeeds removeAllObjects];
    [feeds getHtmlFromURLWithPath:currentPage];
    [SVProgressHUD showInView:self.view];
}

#pragma mark - Init interface

- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
        currentPage = 1;
        feeds = [[Feed alloc] init];
        arrayFeeds = [[NSMutableArray alloc] init];
    }
    return self;
}

- (void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:@"finishLoadRSS" object:nil];
    [feeds release];
    [arrayFeeds release];
    [_refreshHeaderView release];
    [super dealloc];
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(finishLoadRSS) name:@"finishLoadRSS" object:nil];
    [self setupPrototypes];
    [self setupNavButtons];
    [self setupEGORefresh];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [arrayFeeds count] + 1;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.row != [arrayFeeds count]) {
        RSSCell *cell = (RSSCell *)[self tableView:tableView cellForRowAtIndexPath:indexPath];
        return [cell getHeight];
    }
    
    return 44.0f;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSString *CellIdentifier = [NSString  stringWithFormat:@"RSSCell%d", indexPath.row];
    
    if (indexPath.row == [arrayFeeds count]) {
        UITableViewCell *cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"Load more cell"];
        cell.textLabel.textAlignment = UITextAlignmentCenter;
        cell.textLabel.text = @"加载更多...";
        return cell;
    }

    RSSCell *cell = (RSSCell *) [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[[RSSCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
    }
    
    if (!_reloading && [arrayFeeds count] > 0) {
        Feed *feed = [arrayFeeds objectAtIndex:indexPath.row];
        [cell updateCellRss:feed];
    }

    return cell;
}

#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.row != [arrayFeeds count]) {
        Feed *feed = [arrayFeeds objectAtIndex:indexPath.row];
        FeedViewController *fvc = [[FeedViewController alloc] initWithNibName:nil bundle:nil];
        fvc.feed = feed;
        [self.navigationController pushViewController:fvc animated:YES];
        [fvc release];
    } else {
        [self loadMoreFeed];
    }
}

#pragma mark Data Source Loading / Reloading Methods

- (void)reloadTableViewDataSource{
    _reloading = YES;
    currentPage = 1;
    [arrayFeeds removeAllObjects];
    [feeds getHtmlFromURLWithPath:currentPage];
    [self doneLoadingTableViewData];
}

- (void)doneLoadingTableViewData{
    _reloading = NO;
    [_refreshHeaderView egoRefreshScrollViewDataSourceDidFinishedLoading:self.tableView];
}

#pragma mark UIScrollViewDelegate Methods

- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{   
    [_refreshHeaderView egoRefreshScrollViewDidScroll:scrollView];
}

- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate
{
    [_refreshHeaderView egoRefreshScrollViewDidEndDragging:scrollView];
}

#pragma mark EGORefreshTableHeaderDelegate Methods

- (void)egoRefreshTableHeaderDidTriggerRefresh:(EGORefreshTableHeaderView*)view
{
    [self reloadTableViewDataSource];
    [self performSelector:@selector(doneLoadingTableViewData) withObject:nil afterDelay:2.0];
}

- (BOOL)egoRefreshTableHeaderDataSourceIsLoading:(EGORefreshTableHeaderView*)view
{
    return _reloading;
}

- (NSDate*)egoRefreshTableHeaderDataSourceLastUpdated:(EGORefreshTableHeaderView*)view
{
    return [NSDate date];    
} 

@end