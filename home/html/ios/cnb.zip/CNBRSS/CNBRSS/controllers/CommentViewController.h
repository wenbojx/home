#import <UIKit/UIKit.h>
#import "Feed.h"

@interface CommentViewController : UITableViewController
{
    Feed *feed;
    NSMutableArray *arrayComment;
}

@property (nonatomic, retain) Feed *feed;
@property (nonatomic, retain) NSMutableArray *arrayComment;

@end
