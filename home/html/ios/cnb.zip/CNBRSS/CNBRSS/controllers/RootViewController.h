#import <UIKit/UIKit.h>
#import "HJObjManager.h"
#import "Feed.h"
#import "EGORefreshTableHeaderView.h"

@interface RootViewController : UITableViewController <EGORefreshTableHeaderDelegate>
{
    Feed *feeds;
    NSMutableArray *arrayFeeds;
    EGORefreshTableHeaderView *_refreshHeaderView;
    BOOL _reloading;
    int currentPage;
}

@property (nonatomic, retain) Feed *feeds;
@property (nonatomic, retain) NSMutableArray *arrayFeeds;
@property (nonatomic, assign) int currentPage;
@property (nonatomic, retain) EGORefreshTableHeaderView *_refreshHeaderView;

- (void)loadButtonPushed;
- (void)reloadTableViewDataSource;
- (void)doneLoadingTableViewData; 

@end
