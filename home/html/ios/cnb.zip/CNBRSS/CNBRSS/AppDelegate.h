#import <UIKit/UIKit.h>
#import "HJObjManager.h"

@class RootViewController;

@interface AppDelegate : UIResponder <UIApplicationDelegate>
{
    UINavigationController *navigationController;
    RootViewController *rootViewController;
    HJObjManager* imgMan;
}

@property (retain, nonatomic) UIWindow *window;
@property (nonatomic, retain) IBOutlet UINavigationController *navigationController;
@property (nonatomic, retain) RootViewController *rootViewController;
@property (nonatomic, retain) HJObjManager* imgMan;

@end
