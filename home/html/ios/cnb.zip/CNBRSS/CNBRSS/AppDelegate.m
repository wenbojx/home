#import "AppDelegate.h"
#import "RootViewController.h"

// ============================= iOS4 start =========================
@implementation UINavigationBar (UINavigationBarCustom)

- (void)drawRect:(CGRect)rect
{
    UIImage *image = [UIImage imageNamed:@"navBarPortraitCenterFill.png"];
    [image drawInRect:CGRectMake(0, 0, self.frame.size.width, self.frame.size.height)];
}
@end
// ============================= iOS4 end =========================

@implementation AppDelegate

@synthesize window = _window;
@synthesize navigationController;
@synthesize rootViewController;
@synthesize imgMan;

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    imgMan = [[HJObjManager alloc] init];
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    
    rootViewController = [[RootViewController alloc] initWithStyle:UITableViewStylePlain];
    navigationController = [[UINavigationController alloc] initWithRootViewController:rootViewController];
    // ============================= iOS5 start =========================
    if ([[[UIDevice currentDevice] systemVersion] intValue] >= 5.0) {
        [navigationController.navigationBar setBackgroundImage:[UIImage imageNamed:@"navBarPortraitCenterFill.png"] forBarMetrics:UIBarMetricsDefault];
    }
    // ============================= iOS5 end =========================
    // 设置状态栏为黑色
    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleBlackTranslucent];
    
    [self.window setRootViewController:navigationController];
    [self.window makeKeyAndVisible];
    [rootViewController release];
    
    return YES;
}

- (void)dealloc
{
    [imgMan release];
    [rootViewController release];
    [navigationController release];
    [self.window release];
    [super dealloc];
}

//- (void)navigationController:(UINavigationController *)navController willShowViewController:(UIViewController *)viewController animated:(BOOL)animated
//{
//    if ([viewController respondsToSelector:@selector(willAppearIn:)])
//        [viewController performSelector:@selector(willAppearIn:) withObject:navController];
//}

@end
