//
//  AppDelegate.h
//  TabBarSimple
//
//  Created by Wang Liang on 12-2-1.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class MainWindow;

@interface AppDelegate : UIResponder <UIApplicationDelegate>
{
    UITabBarController *tabBarController;
}

@property (strong, nonatomic) UIWindow *window;
@property (nonatomic, retain) IBOutlet UITabBarController *tabBarController;

@end
