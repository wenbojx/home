//
//  FirestViewController.h
//  TabBarSimple
//
//  Created by Wang Liang on 12-2-2.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FirestViewController : UIViewController

@end
