//
//  RootViewController.h
//  NavigationDemo
//
//  Created by Wang Liang on 12-1-23.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RootViewController : UIViewController

- (IBAction)displaySecondView:(id)sender;

@end
