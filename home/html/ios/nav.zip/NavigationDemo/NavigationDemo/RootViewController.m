//
//  RootViewController.m
//  NavigationDemo
//
//  Created by Wang Liang on 12-1-23.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "RootViewController.h"
#import "SecondViewController.h"

@implementation RootViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    UIBarButtonItem *testButton = [[UIBarButtonItem alloc] initWithTitle:@"test" style:UIBarButtonItemStyleBordered target:self action:@selector(testClicked:)];
    self.navigationItem.leftBarButtonItem = testButton;
    //UITabBarItem *item = [[UITabBarItem alloc] initWithTabBarSystemItem:UITabBarSystemItemBookmarks tag:0];
    
    //UIBarButtonItem *addButton =[[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemAdd target:self action:@selector(addClicked:)];
    //self.navigationItem.rightBarButtonItem = addButton;
    
    self.navigationItem.rightBarButtonItem = self.editButtonItem;
    NSArray *segmentButtons = [NSArray arrayWithObjects:@"升序", @"降序", nil];
    UISegmentedControl *segmentedController = [[UISegmentedControl alloc] initWithItems:segmentButtons];
    segmentedController.segmentedControlStyle = UISegmentedControlStyleBar;
    [segmentedController addTarget:self action:@selector(segmentAction:) forControlEvents:UIControlEventValueChanged];
    self.navigationItem.titleView = segmentedController;
    
    UIBarButtonItem *backButton = [[UIBarButtonItem alloc] initWithTitle:@"Root" style:UIBarButtonItemStylePlain target:nil action:nil];
    self.navigationItem.backBarButtonItem = backButton;
    //self.tabBarItem = item;
    
    [testButton release];
    [segmentedController release];
    [backButton release];
    //[item release];
    //[addButton release];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (void)displaySecondView:(id)sender
{
    SecondViewController *secondViewController = [[SecondViewController alloc] init];
    [self.navigationController pushViewController:secondViewController animated:YES];
    secondViewController.title = @"Second View";
    
    [secondViewController release];
}

- (void)setEditing:(BOOL)editing animated:(BOOL)animated
{
    [super setEditing:editing animated:animated];
    if (editing) {
        NSLog(@"editing");
    } else {
        NSLog(@"done");
    }
}

- (void)testClicked:(id)sender
{
    NSLog(@"test button clicked.");
}

- (void)addClicked:(id)sender
{
    NSLog(@"add button clicked.");
}

- (void)segmentAction:(id)sender
{
    switch ([sender selectedSegmentIndex]) {
        case 0:
            NSLog(@"button 0 clicked");
            break;
            
        case 1:
            NSLog(@"button 1 clicked");
            break;
            
        default:
            break;
    }
}

@end
