//
//  AppDelegate.h
//  NavigationDemo
//
//  Created by Wang Liang on 12-1-23.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>
{
    UINavigationController *navController;
    UITabBarController *tabBarController;
}

@property (strong, nonatomic) UIWindow *window;

@end
