// Copyright (c) 2009 wikihow.com and Keishi Hattori
// 
// Permission is hereby granted, free of charge, to any person
// obtaining a copy of this software and associated documentation
// files (the "Software"), to deal in the Software without
// restriction, including without limitation the rights to use,
// copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the
// Software is furnished to do so, subject to the following
// conditions:
// 
// The above copyright notice and this permission notice shall be
// included in all copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
// EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
// OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
// NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
// HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
// WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
// FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
// OTHER DEALINGS IN THE SOFTWARE.

#import "WHToggleSwitchPreference.h"


@implementation WHToggleSwitchPreference

@synthesize cell;
@synthesize key;
@synthesize toggleSwitch;

- (id)initWithSpecifier:(NSDictionary *)specifier {
    if (self = [super init]) {
		key = [[specifier objectForKey:@"Key"] copy];
		
		toggleSwitch = [[UISwitch alloc] initWithFrame:CGRectMake(190, 9, 0, 0)];
		[toggleSwitch addTarget:self action:@selector(switchDidChange:) forControlEvents:UIControlEventValueChanged];
		
		if ([[NSUserDefaults standardUserDefaults] objectForKey:key]) {
			toggleSwitch.on = [[NSUserDefaults standardUserDefaults] boolForKey:key];
		} else {
			toggleSwitch.on = [[[specifier objectForKey:@"DefaultValue"] description] isEqualToString:@"1"];
		}
		
		cell = [[UITableViewCell alloc] initWithFrame:CGRectZero reuseIdentifier:@"ToggleSwitchCell"];
		cell.text = [specifier objectForKey:@"Title"];
		cell.selectionStyle = UITableViewCellSelectionStyleNone;
		[cell addSubview:toggleSwitch];
    }
    return self;
}

- (void)switchDidChange:(id)sender {
	[[NSUserDefaults standardUserDefaults] setBool:toggleSwitch.on forKey:key];
}

@end
